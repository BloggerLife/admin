import CollectionForm from "@/components/collections/CollectionForm"

const CreateCollection = () => {
  return (
    <CollectionForm />
  )
}

export default CreateCollection